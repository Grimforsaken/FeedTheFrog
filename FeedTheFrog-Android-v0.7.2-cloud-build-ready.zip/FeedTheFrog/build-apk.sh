#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [[ ! -f local.properties && -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Android SDK location not configured."
  echo "Copy local.properties.example to local.properties and set sdk.dir,"
  echo "or set ANDROID_HOME / ANDROID_SDK_ROOT."
  exit 2
fi

if [[ -x /mnt/data/gradle-9.7.1/bin/gradle ]]; then
  GRADLE=/mnt/data/gradle-9.7.1/bin/gradle
elif command -v gradle >/dev/null 2>&1; then
  GRADLE="$(command -v gradle)"
else
  GRADLE="$ROOT/gradlew"
fi

echo "Using Gradle: $GRADLE"
"$GRADLE" --version | sed -n '1,12p'
"$GRADLE" --no-daemon clean assembleDebug

APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then
  echo
  echo "APK created: $APK"
  ls -lh "$APK"
else
  echo "Build finished but APK was not found at the expected path."
  exit 3
fi
